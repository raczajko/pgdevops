from pygtail.core import __version__
from pygtail.core import Pygtail
